import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { api } from '../api';
import './BookingForm.css';

// Mock hotels data
const hotelsByLocation = {
  "Paris": [
    { id: 1, name: "Luxury Paris Hotel", rating: 5, price: 300, amenities: ["WiFi", "Pool", "Spa"] },
    { id: 2, name: "Eiffel Tower View", rating: 4, price: 200, amenities: ["WiFi", "Breakfast"] },
    { id: 3, name: "Champs-Élysées Suites", rating: 4.5, price: 250, amenities: ["WiFi", "Gym", "Bar"] }
  ],
  "New York": [
    { id: 4, name: "Manhattan Grand", rating: 5, price: 400, amenities: ["WiFi", "Pool", "Spa", "Gym"] },
    { id: 5, name: "Central Park View", rating: 4.5, price: 350, amenities: ["WiFi", "Breakfast", "Gym"] },
    { id: 6, name: "Times Square Hotel", rating: 4, price: 280, amenities: ["WiFi", "Business Center"] }
  ],
  "Tokyo": [
    { id: 7, name: "Tokyo Imperial", rating: 5, price: 320, amenities: ["WiFi", "Spa", "Restaurant"] },
    { id: 8, name: "Shibuya City Hotel", rating: 4, price: 220, amenities: ["WiFi", "Concierge"] },
    { id: 9, name: "Ginza Luxury Suites", rating: 4.5, price: 280, amenities: ["WiFi", "Spa", "Bar"] }
  ],
  "London": [
    { id: 10, name: "London Royal Hotel", rating: 5, price: 350, amenities: ["WiFi", "Pool", "Spa", "Afternoon Tea"] },
    { id: 11, name: "Thames River View", rating: 4, price: 240, amenities: ["WiFi", "Breakfast"] },
    { id: 12, name: "Buckingham Suites", rating: 4.5, price: 290, amenities: ["WiFi", "Gym", "Bar"] }
  ],
  "Dubai": [
    { id: 13, name: "Burj Khalifa View", rating: 5, price: 500, amenities: ["WiFi", "Pool", "Spa", "Luxury Shuttle"] },
    { id: 14, name: "Palm Jumeirah Resort", rating: 5, price: 450, amenities: ["WiFi", "Private Beach", "Spa"] },
    { id: 15, name: "Dubai Marina Hotel", rating: 4.5, price: 320, amenities: ["WiFi", "Pool", "Gym"] }
  ],
  "Bali": [
    { id: 16, name: "Beachfront Villa", rating: 5, price: 200, amenities: ["WiFi", "Private Pool", "Beach Access"] },
    { id: 17, name: "Ubud Jungle Retreat", rating: 4.5, price: 180, amenities: ["WiFi", "Yoga", "Spa"] },
    { id: 18, name: "Seminyak Luxury Resort", rating: 4, price: 220, amenities: ["WiFi", "Pool", "Restaurant"] }
  ]
};

const BookingForm = () => {
  const { user } = useAuth();
  const [locations, setLocations] = useState([]);
  const [selectedLocations, setSelectedLocations] = useState([]);
  const [bookingDate, setBookingDate] = useState('');
  const [totalPrice, setTotalPrice] = useState(0);
  const [message, setMessage] = useState('');
  const [bookingId, setBookingId] = useState('');
  const [activeTab, setActiveTab] = useState('user');
  const [userName, setUserName] = useState('');
  const [selectedHotels, setSelectedHotels] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  useEffect(() => {
    generateBookingId();
    loadLocations();
    if (user?.username) {
      setUserName(user.username);
    }
  }, [user]);

  useEffect(() => {
    calculateTotalPrice();
  }, [selectedLocations, selectedHotels, locations]);

  const generateBookingId = () => {
    const timestamp = new Date().getTime().toString().slice(-6);
    const random = Math.random().toString(36).substring(2, 5).toUpperCase();
    const newBookingId = `BK-${timestamp}-${random}`;
    setBookingId(newBookingId);
    return newBookingId;
  };

  const loadLocations = async () => {
    try {
      const response = await api.getLocations();
      if (response.ok) {
        const data = await response.json();
        setLocations(data);
      } else {
        throw new Error('Failed to load locations');
      }
    } catch (error) {
      console.error('Error loading locations:', error);
      // Fallback to mock data if API fails
      setLocations([
        { name: "Paris", fee: 1200 },
        { name: "New York", fee: 1500 },
        { name: "Tokyo", fee: 1800 },
        { name: "London", fee: 1300 },
        { name: "Dubai", fee: 1600 },
        { name: "Bali", fee: 1100 }
      ]);
    }
  };

  const calculateTotalPrice = () => {
    const locationsTotal = selectedLocations.reduce((sum, locName) => {
      const location = locations.find(l => l.name === locName);
      return sum + (location ? location.fee : 0);
    }, 0);
    
    const hotelsTotal = Object.values(selectedHotels).reduce((sum, hotel) => {
      return sum + (hotel ? hotel.price : 0);
    }, 0);
    
    setTotalPrice(locationsTotal + hotelsTotal);
  };

  const handleLocationToggle = (locationName) => {
    setSelectedLocations(prev => {
      if (prev.includes(locationName)) {
        // Remove location and its hotel selection
        const newSelectedHotels = { ...selectedHotels };
        delete newSelectedHotels[locationName];
        setSelectedHotels(newSelectedHotels);
        return prev.filter(loc => loc !== locationName);
      } else {
        return [...prev, locationName];
      }
    });
  };

  const handleHotelSelect = (locationName, hotel) => {
    setSelectedHotels(prev => ({
      ...prev,
      [locationName]: hotel
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setMessage('');
    
    if (!userName.trim()) {
      setMessage('Please enter your name');
      setIsSubmitting(false);
      return;
    }
    
    if (selectedLocations.length === 0 || !bookingDate) {
      setMessage('Please select at least one location and choose a date');
      setIsSubmitting(false);
      return;
    }

    try {
      const formattedDate = new Date(bookingDate).toISOString().split('T')[0];
      
      const bookingData = {
        booking_id: bookingId,  // ✅ Now included
        user_id: userName,
        user_name: userName,
        locations: selectedLocations,
        hotels: selectedHotels,
        booking_date: formattedDate,
        total_price: totalPrice
      };

      console.log('Sending booking data to backend:', bookingData);

      const response = await api.createBooking(bookingData);
      
      if (response.ok) {
        const result = await response.json();
        console.log('Booking created in backend:', result);
        setMessage(`✅ Booking created successfully! Booking ID: ${result.booking_id || result.id || bookingId}`);
        
        // Trigger dashboard refresh
        window.dispatchEvent(new CustomEvent('bookingCreated'));
        
        // Reset form and generate new ID
        setSelectedLocations([]);
        setSelectedHotels({});
        setBookingDate('');
        setTotalPrice(0);
        setUserName(user?.username || '');
        generateBookingId();
        setActiveTab('user');
      } else {
        const errorText = await response.text();
        let errorData;
        try {
          errorData = JSON.parse(errorText);
        } catch {
          errorData = { detail: errorText || 'Unknown error occurred' };
        }
        console.error('Backend error:', errorData);
        setMessage(`❌ Error: ${errorData.detail || errorData.message || JSON.stringify(errorData)}`);
      }
    } catch (error) {
      console.error('Network error:', error);
      setMessage(`❌ Network error: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const nextTab = () => {
    if (activeTab === 'user' && userName.trim()) {
      setActiveTab('locations');
    } else if (activeTab === 'locations' && selectedLocations.length > 0) {
      setActiveTab('hotels');
    } else if (activeTab === 'hotels' && Object.keys(selectedHotels).length === selectedLocations.length) {
      setActiveTab('date');
    } else if (activeTab === 'date' && bookingDate) {
      setActiveTab('summary');
    }
  };

  const prevTab = () => {
    if (activeTab === 'locations') {
      setActiveTab('user');
    } else if (activeTab === 'hotels') {
      setActiveTab('locations');
    } else if (activeTab === 'date') {
      setActiveTab('hotels');
    } else if (activeTab === 'summary') {
      setActiveTab('date');
    }
  };

  const getStarRating = (rating) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    return (
      <>
        {'⭐'.repeat(fullStars)}
        {hasHalfStar && '⭐'}
        <span className="rating-text">({rating})</span>
      </>
    );
  };

  // Helper to check if all required hotel selections are made
  const areAllHotelsSelected = () => {
    return selectedLocations.every(location => selectedHotels[location]);
  };

  return (
    <div className="booking-container">
      <div className="booking-header">
        <h2>🌍 Create Your Travel Booking</h2>
        <div className="user-info-badge">
          <span className="user-icon">👤</span>
          <span className="username">{user?.username || 'Guest'}</span>
          <span className="booking-id">ID: {bookingId}</span>
        </div>
      </div>

      {/* Progress Tabs */}
      <div className="progress-tabs">
        <div className={`tab ${activeTab === 'user' ? 'active' : ''} ${userName ? 'completed' : ''}`}>
          <div className="tab-number">1</div>
          <div className="tab-label">Your Name</div>
        </div>
        <div className={`tab ${activeTab === 'locations' ? 'active' : ''} ${selectedLocations.length > 0 ? 'completed' : ''}`}>
          <div className="tab-number">2</div>
          <div className="tab-label">Select Locations</div>
        </div>
        <div className={`tab ${activeTab === 'hotels' ? 'active' : ''} ${areAllHotelsSelected() ? 'completed' : ''}`}>
          <div className="tab-number">3</div>
          <div className="tab-label">Choose Hotels</div>
        </div>
        <div className={`tab ${activeTab === 'date' ? 'active' : ''} ${bookingDate ? 'completed' : ''}`}>
          <div className="tab-number">4</div>
          <div className="tab-label">Choose Date</div>
        </div>
        <div className={`tab ${activeTab === 'summary' ? 'active' : ''}`}>
          <div className="tab-number">5</div>
          <div className="tab-label">Confirm Booking</div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="booking-form">
        {/* Tab 1: User Name */}
        {activeTab === 'user' && (
          <div className="form-tab active">
            <h3>👤 Enter Your Name</h3>
            <p className="tab-description">Please provide your name for the booking</p>
            <div className="user-input-section">
              <div className="input-card">
                <label htmlFor="userName" className="input-label">
                  Full Name
                </label>
                <input
                  id="userName"
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="Enter your full name"
                  className="name-input"
                  required
                />
                {user?.username && (
                  <p className="suggestion">
                    Suggestion: Using your account name <strong>{user.username}</strong>
                  </p>
                )}
              </div>
              <div className="user-preview">
                <h4>Booking Preview:</h4>
                <div className="preview-card">
                  <div className="preview-row">
                    <span>Booking ID:</span>
                    <span className="preview-value">{bookingId}</span>
                  </div>
                  <div className="preview-row">
                    <span>Name:</span>
                    <span className="preview-value">{userName || 'Not provided'}</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="tab-actions">
              <button 
                type="button" 
                className="btn-primary"
                onClick={nextTab}
                disabled={!userName.trim()}
              >
                Next: Select Locations →
              </button>
            </div>
          </div>
        )}

        {/* Tab 2: Locations */}
        {activeTab === 'locations' && (
          <div className="form-tab active">
            <h3>✈️ Select Your Dream Destinations</h3>
            <p className="tab-description">Choose one or multiple locations for your trip</p>
            <div className="locations-grid">
              {locations.map(location => (
                <div 
                  key={location.name} 
                  className={`location-card ${selectedLocations.includes(location.name) ? 'selected' : ''}`}
                  onClick={() => handleLocationToggle(location.name)}
                >
                  <div className="location-checkbox">
                    <input
                      type="checkbox"
                      checked={selectedLocations.includes(location.name)}
                      readOnly
                    />
                    <span className="checkmark"></span>
                  </div>
                  <div className="location-content">
                    <div className="location-name">{location.name}</div>
                    <div className="location-price">${location.fee}</div>
                    <div className="location-desc">Popular destination</div>
                  </div>
                </div>
              ))}
            </div>
            <div className="selected-count">
              {selectedLocations.length} location(s) selected
            </div>
            <div className="tab-actions">
              <button type="button" className="btn-secondary" onClick={prevTab}>
                ← Back to User Details
              </button>
              <button 
                type="button" 
                className="btn-primary"
                onClick={nextTab}
                disabled={selectedLocations.length === 0}
              >
                Next: Choose Hotels →
              </button>
            </div>
          </div>
        )}

        {/* Tab 3: Hotel Selection */}
        {activeTab === 'hotels' && (
          <div className="form-tab active">
            <h3>🏨 Choose Your Hotels</h3>
            <p className="tab-description">Select one hotel for each location</p>
            
            <div className="hotels-selection">
              {selectedLocations.map(locationName => (
                <div key={locationName} className="location-hotels-section">
                  <h4 className="location-title">🏙️ {locationName}</h4>
                  <div className="hotels-grid">
                    {hotelsByLocation[locationName]?.map(hotel => (
                      <div 
                        key={hotel.id}
                        className={`hotel-card ${
                          selectedHotels[locationName]?.id === hotel.id ? 'selected' : ''
                        }`}
                        onClick={() => handleHotelSelect(locationName, hotel)}
                      >
                        {hotel.rating === 5 && <div className="premium-badge">PREMIUM</div>}
                        
                        <div className="hotel-checkbox">
                          <input
                            type="radio"
                            name={`hotel-${locationName}`}
                            checked={selectedHotels[locationName]?.id === hotel.id}
                            readOnly
                          />
                          <span className="radiomark"></span>
                        </div>
                        
                        <div className="hotel-content">
                          <div className="hotel-name">{hotel.name}</div>
                          <div className="hotel-rating">
                            <span className="stars">
                              {getStarRating(hotel.rating)}
                            </span>
                          </div>
                          <div className="hotel-price">${hotel.price}/night</div>
                          <div className="hotel-amenities">
                            {hotel.amenities.map((amenity, index) => (
                              <span key={index} className="amenity-tag">{amenity}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  {!selectedHotels[locationName] && (
                    <div className="selection-required">Please select a hotel for {locationName}</div>
                  )}
                </div>
              ))}
            </div>

            <div className="selection-progress">
              {Object.keys(selectedHotels).length} of {selectedLocations.length} hotels selected
            </div>

            <div className="tab-actions">
              <button type="button" className="btn-secondary" onClick={prevTab}>
                ← Back to Locations
              </button>
              <button 
                type="button" 
                className="btn-primary"
                onClick={nextTab}
                disabled={!areAllHotelsSelected()}
              >
                Next: Choose Date →
              </button>
            </div>
          </div>
        )}

        {/* Tab 4: Date Selection */}
        {activeTab === 'date' && (
          <div className="form-tab active">
            <h3>📅 Select Your Travel Date</h3>
            <p className="tab-description">Choose when you want to travel</p>
            <div className="date-selection">
              <div className="calendar-card">
                <div className="calendar-icon">📅</div>
                <input
                  type="date"
                  value={bookingDate}
                  onChange={(e) => setBookingDate(e.target.value)}
                  required
                  className="date-input"
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>
              {bookingDate && (
                <div className="date-preview">
                  <h4>Selected Date:</h4>
                  <p>{new Date(bookingDate).toLocaleDateString('en-US', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}</p>
                </div>
              )}
            </div>
            <div className="tab-actions">
              <button type="button" className="btn-secondary" onClick={prevTab}>
                ← Back to Hotels
              </button>
              <button 
                type="button" 
                className="btn-primary"
                onClick={nextTab}
                disabled={!bookingDate}
              >
                Next: Review Booking →
              </button>
            </div>
          </div>
        )}

        {/* Tab 5: Summary */}
        {activeTab === 'summary' && (
          <div className="form-tab active">
            <h3>✅ Review Your Booking</h3>
            <p className="tab-description">Please confirm your booking details</p>
            <div className="booking-summary-card">
              <div className="summary-section">
                <h4>👤 Personal Information</h4>
                <div className="summary-row">
                  <span>Full Name:</span>
                  <span className="user-name-highlight">{userName}</span>
                </div>
                <div className="summary-row">
                  <span>Booking ID:</span>
                  <span className="booking-id-highlight">{bookingId}</span>
                </div>
              </div>

              <div className="summary-section">
                <h4>✈️ Selected Locations</h4>
                {selectedLocations.map(locationName => {
                  const location = locations.find(l => l.name === locationName);
                  return (
                    <div key={locationName} className="summary-row">
                      <span>{locationName}</span>
                      <span>${location?.fee}</span>
                    </div>
                  );
                })}
              </div>

              <div className="summary-section">
                <h4>🏨 Selected Hotels</h4>
                {Object.entries(selectedHotels).map(([locationName, hotel]) => (
                  <div key={locationName} className="summary-row">
                    <div>
                      <strong>{locationName}:</strong> {hotel.name}
                      <div className="hotel-details">
                        ⭐ {hotel.rating} • ${hotel.price}/night
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="summary-section">
                <h4>📅 Travel Date</h4>
                <div className="summary-row">
                  <span>Date:</span>
                  <span>{new Date(bookingDate).toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}</span>
                </div>
                <div className="summary-row">
                  <span>Season:</span>
                  <span className="season-badge">
                    {(() => {
                      const month = new Date(bookingDate).getMonth() + 1;
                      if (month >= 3 && month <= 5) return 'Spring';
                      if (month >= 6 && month <= 8) return 'Summer';
                      if (month >= 9 && month <= 11) return 'Fall';
                      return 'Winter';
                    })()}
                  </span>
                </div>
              </div>

              <div className="summary-section total-section">
                <h4>💰 Total Amount</h4>
                <div className="total-price">${totalPrice}</div>
                <p className="tax-note">*Includes all taxes and fees</p>
              </div>
            </div>

            <div className="tab-actions">
              <button type="button" className="btn-secondary" onClick={prevTab}>
                ← Back to Date
              </button>
              <button 
                type="submit" 
                className="btn-success"
                disabled={isSubmitting}
              >
                {isSubmitting ? '⏳ Creating Booking...' : '🎉 Confirm & Book Now'}
              </button>
            </div>
          </div>
        )}

        {message && (
          <div className={`message ${message.includes('✅') ? 'success' : 'error'}`}>
            {message}
          </div>
        )}
      </form>
    </div>
  );
};

export default BookingForm;