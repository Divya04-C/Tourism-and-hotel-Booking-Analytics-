import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import './Navigation.css';

const Navigation = () => {
  const { user, logout, isAdmin } = useAuth();

  return (
    <nav className="navigation">
      <div className="nav-brand">
        <Link to="/booking" style={{ color: 'white', textDecoration: 'none' }}>
          Tourism Analytics
        </Link>
      </div>
      <div className="nav-links">
        <Link to="/booking">Booking</Link>
        
        {/* Show Analytics only for Admin - REMOVED Admin Dashboard */}
        {isAdmin && <Link to="/analytics">Analytics</Link>}
        
        <span className="user-info">
          <span className="username">Welcome, {user?.username}</span>
          <span className="user-type">{user?.userType === 'admin' ? '🔧 Admin' : '👤 User'}</span>
        </span>
        <button onClick={logout} className="logout-btn">Logout</button>
      </div>
    </nav>
  );
};

export default Navigation;