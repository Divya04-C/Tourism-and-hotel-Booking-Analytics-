import React, { useState, useEffect } from 'react';
import { api } from '../api';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area
} from 'recharts';
import './AnalyticsDashboard.css';

const AnalyticsDashboard = () => {
  const [mostVisited, setMostVisited] = useState([]);
  const [averagePrice, setAveragePrice] = useState([]);
  const [bookingPatterns, setBookingPatterns] = useState([]);
  const [allBookings, setAllBookings] = useState([]);
  const [revenueData, setRevenueData] = useState([]);
  const [revenueStats, setRevenueStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [lastUpdate, setLastUpdate] = useState(Date.now());

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

  useEffect(() => {
    loadAllData();
    
    const interval = setInterval(() => {
      loadAllData();
    }, 5000);

    const handleBookingCreated = () => {
      console.log('Booking created event received, refreshing data...');
      loadAllData();
    };

    window.addEventListener('bookingCreated', handleBookingCreated);

    return () => {
      clearInterval(interval);
      window.removeEventListener('bookingCreated', handleBookingCreated);
    };
  }, []);

  useEffect(() => {
    const fetchRevenueStats = async () => {
      try {
        const response = await api.getRevenueAnalytics();
        if (response.ok) {
          const data = await response.json();
          console.log('Revenue API Data:', data);
          setRevenueStats(data[0]);
        }
      } catch (error) {
        console.error('Error fetching revenue data:', error);
      }
    };

    fetchRevenueStats();
  }, [lastUpdate]);

  const loadAllData = async () => {
    try {
      setLoading(true);
      
      console.log('Loading admin dashboard data...');
      
      const [visitedRes, priceRes, patternsRes, bookingsRes] = await Promise.all([
        api.getMostVisited(),
        api.getAveragePrice(),
        api.getBookingPatterns(),
        api.getBookings()
      ]);

      if (visitedRes.ok && priceRes.ok && patternsRes.ok && bookingsRes.ok) {
        const visitedData = await visitedRes.json();
        const priceData = await priceRes.json();
        const patternsData = await patternsRes.json();
        const bookingsData = await bookingsRes.json();

        console.log('All Bookings Data:', bookingsData);
        console.log('Bookings count:', bookingsData.length);

        setMostVisited(visitedData);
        setAveragePrice(priceData);
        setBookingPatterns(patternsData);
        
        const processedBookings = processBookingsData(bookingsData);
        setAllBookings(processedBookings);
        
        const revenue = processRevenueData(processedBookings);
        setRevenueData(revenue);
        
        setLastUpdate(Date.now());
      } else {
        console.error('Failed to fetch admin data');
      }
    } catch (error) {
      console.error('Error loading admin analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const processBookingsData = (bookings) => {
    return bookings.map(booking => {
      if (booking.user_name === 'Unknown User' && booking.user_id && booking.user_id !== 'Unknown User') {
        return {
          ...booking,
          user_name: booking.user_id,
          user_id: booking.user_id
        };
      }
      
      if ((!booking.user_name || booking.user_name === 'Unknown User') && booking.user_id) {
        return {
          ...booking,
          user_name: booking.user_id
        };
      }
      
      if (!booking.user_name && !booking.user_id) {
        return {
          ...booking,
          user_name: 'Guest User',
          user_id: 'guest'
        };
      }
      
      return booking;
    });
  };

  const processRevenueData = (bookings) => {
    const revenueByDate = {};
    bookings.forEach(booking => {
      if (booking.booking_date) {
        if (!revenueByDate[booking.booking_date]) {
          revenueByDate[booking.booking_date] = 0;
        }
        revenueByDate[booking.booking_date] += booking.total_price || 0;
      }
    });
    
    return Object.entries(revenueByDate).map(([date, revenue]) => ({
      date,
      revenue
    })).sort((a, b) => new Date(a.date) - new Date(b.date));
  };

  const getStats = () => {
    if (revenueStats) {
      return {
        totalBookings: revenueStats.total_bookings || 0,
        totalRevenue: revenueStats.total_revenue || 0,
        avgBookingValue: revenueStats.average_booking_value || 0
      };
    }

    const totalBookings = allBookings.length;
    const totalRevenue = allBookings.reduce((sum, booking) => sum + (booking.total_price || 0), 0);
    const avgBookingValue = totalBookings > 0 ? totalRevenue / totalBookings : 0;

    return { totalBookings, totalRevenue, avgBookingValue };
  };

  const stats = getStats();

  if (loading) {
    return <div className="loading">Loading admin dashboard...</div>;
  }

  return (
    <div className="admin-dashboard">
      <div className="dashboard-header">
        <h2>🔧 Admin Dashboard</h2>
        <div style={{display: 'flex', alignItems: 'center', gap: '15px'}}>
          <span style={{fontSize: '12px', color: 'rgba(255,255,255,0.7)'}}>
            Last updated: {new Date(lastUpdate).toLocaleTimeString()}
          </span>
          <button onClick={loadAllData} className="refresh-btn">
            🔄 Refresh Data
          </button>
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon">📊</div>
          <div className="stat-content">
            <h3>{stats.totalBookings}</h3>
            <p>Total Bookings</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">💰</div>
          <div className="stat-content">
            <h3>${stats.totalRevenue.toFixed(2)}</h3>
            <p>Total Revenue</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">📈</div>
          <div className="stat-content">
            <h3>${stats.avgBookingValue.toFixed(2)}</h3>
            <p>Avg. Booking Value</p>
          </div>
        </div>
      </div>

      <div className="admin-tabs">
        <button 
          className={`tab-btn ${activeTab === 'overview' ? 'active' : ''}`}
          onClick={() => setActiveTab('overview')}
        >
          📊 Overview
        </button>
        <button 
          className={`tab-btn ${activeTab === 'bookings' ? 'active' : ''}`}
          onClick={() => setActiveTab('bookings')}
        >
          📋 All Bookings ({allBookings.length})
        </button>
        <button 
          className={`tab-btn ${activeTab === 'revenue' ? 'active' : ''}`}
          onClick={() => setActiveTab('revenue')}
        >
          💰 Revenue
        </button>
      </div>

      <div className="tab-content">
        {activeTab === 'overview' && (
          <div className="overview-grid">
            <div className="chart-card">
              <h3>📍 Most Visited Locations</h3>
              {mostVisited.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={mostVisited}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="_id" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="count" fill="#8884d8" name="Number of Bookings" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="no-data">No location data available</div>
              )}
            </div>

            <div className="chart-card">
              <h3>🌤️ Average Price by Season</h3>
              {averagePrice.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={averagePrice}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="_id" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="average_price" fill="#82ca9d" name="Average Price ($)" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="no-data">No season data available</div>
              )}
            </div>

            <div className="chart-card">
              <h3>📅 Booking Patterns</h3>
              {bookingPatterns.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={bookingPatterns}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ _id, count }) => `${_id}: ${count}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                      nameKey="_id"
                    >
                      {bookingPatterns.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="no-data">No booking pattern data available</div>
              )}
            </div>

            <div className="chart-card">
              <h3>💰 Revenue Trend</h3>
              {revenueData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area type="monotone" dataKey="revenue" stroke="#ff7300" fill="#ff7300" fillOpacity={0.3} />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="no-data">No revenue data available</div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'bookings' && (
          <div className="bookings-tab">
            <h3>📋 All Bookings ({allBookings.length})</h3>
            <div className="bookings-table-container">
              {allBookings.length > 0 ? (
                <table className="bookings-table">
                  <thead>
                    <tr>
                      <th>Booking ID</th>
                      <th>User Name</th>
                      <th>Locations</th>
                      <th>Date</th>
                      <th>Total Price</th>
                      <th>Season</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allBookings.map((booking, index) => (
                      <tr key={booking.booking_id || index}>
                        <td className="booking-id-cell">
                          {booking.booking_id || `BK-${index + 1}`}
                        </td>
                        <td className="user-cell">
                          {booking.user_name || 'Guest User'}
                        </td>
                        <td className="locations-cell">
                          {Array.isArray(booking.locations) 
                            ? booking.locations.join(', ')
                            : booking.locations || 'No locations'
                          }
                        </td>
                        <td className="date-cell">
                          {booking.booking_date || 'No date'}
                        </td>
                        <td className="price-cell">
                          ${booking.total_price || 0}
                        </td>
                        <td className="season-cell">
                          {booking.season || 'N/A'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="no-data">No bookings found</div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'revenue' && (
          <div className="revenue-tab">
            <h3>💰 Revenue Analytics</h3>
            <div className="revenue-charts">
              <div className="chart-card">
                <h4>Revenue Over Time</h4>
                {revenueData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={revenueData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="revenue" stroke="#8884d8" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="no-data">No revenue data available</div>
                )}
              </div>
              
              <div className="revenue-breakdown">
                <h4>Revenue Breakdown</h4>
                <div className="revenue-stats">
                  <div className="revenue-stat">
                    <span className="stat-name">Total Revenue:</span>
                    <span className="stat-amount">${stats.totalRevenue.toFixed(2)}</span>
                  </div>
                  <div className="revenue-stat">
                    <span className="stat-name">Total Bookings:</span>
                    <span className="stat-amount">{stats.totalBookings}</span>
                  </div>
                  <div className="revenue-stat">
                    <span className="stat-name">Average Booking Value:</span>
                    <span className="stat-amount">${stats.avgBookingValue.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AnalyticsDashboard;