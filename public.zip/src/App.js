import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./hooks/useAuth";
import Login from "./components/Login";
import BookingForm from "./components/BookingForm";
import AnalyticsDashboard from "./components/AnalyticsDashboard";
import Navigation from "./components/Navigation";
import "./styles/global.css";

// Error Boundary for safety
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  
  static getDerivedStateFromError(error) {
    return { hasError: true };
  }
  
  componentDidCatch(error, errorInfo) {
    console.error("App Error:", error, errorInfo);
  }
  
  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '20px', color: 'red' }}>
          <h2>Something went wrong with the app.</h2>
          <p>Check the browser console for errors.</p>
        </div>
      );
    }
    return this.props.children;
  }
}
function AppContent() {
  const { isAuthenticated, isAdmin } = useAuth();
  console.log('AppContent - isAuthenticated:', isAuthenticated);
  console.log('AppContent - isAdmin:', isAdmin);
  return (
    <div className="App">
      {isAuthenticated && <Navigation />}
      <Routes>
        <Route 
          path="/" 
          element={isAuthenticated ? <Navigate to="/booking" /> : <Login />} 
        />
        <Route 
          path="/booking" 
          element={isAuthenticated ? <BookingForm /> : <Navigate to="/" />} 
        />
        {/* Only Analytics route for admins - Removed /admin route */}
        <Route 
          path="/analytics" 
          element={
            isAuthenticated && isAdmin ? (
              <AnalyticsDashboard />
            ) : isAuthenticated ? (
              <Navigate to="/booking" />
            ) : (
              <Navigate to="/" />
            )
          } 
        />
      </Routes>
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <Router>
          <AppContent />
        </Router>
      </AuthProvider>
    </ErrorBoundary>
  );
}

export default App;