const API_BASE = "http://localhost:8000/api/v1";

export const api = {
  // Auth
  login: (username, password) => 
    fetch(`${API_BASE}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    }),
  
  register: (username, password) => 
    fetch(`${API_BASE}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    }),

  // Bookings
  createBooking: (bookingData) =>
    fetch(`${API_BASE}/bookings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(bookingData)
    }),

  getBookings: () => fetch(`${API_BASE}/bookings`),

  // Analytics - UPDATED WITH NEW ENDPOINTS
  getMostVisited: () => fetch(`${API_BASE}/analytics/most-visited`),
  getAveragePrice: () => fetch(`${API_BASE}/analytics/average-price-season`),
  getBookingPatterns: () => fetch(`${API_BASE}/analytics/booking-patterns`),
  getRevenueAnalytics: () => fetch(`${API_BASE}/analytics/revenue`),
  getPopularSeasons: () => fetch(`${API_BASE}/analytics/popular-seasons`),

  // Locations
  getLocations: () => fetch(`${API_BASE}/locations`),

  // User bookings
  getUserBookings: (userId) => fetch(`${API_BASE}/bookings/user/${userId}`)
};