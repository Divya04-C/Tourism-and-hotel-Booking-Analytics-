import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const login = (userData) => {
    console.log('Logging in user:', userData);
    const userWithType = {
      ...userData,
      userType: userData.userType || 'user',
      isAdmin: userData.userType === 'admin'
    };
    setUser(userWithType);
    setIsAuthenticated(true);
    localStorage.setItem('user', JSON.stringify(userWithType));
  };

  const logout = () => {
    console.log('Logging out');
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('user');
  };

  // Check if user is admin
  const isAdmin = () => {
    return user?.userType === 'admin' || user?.isAdmin;
  };

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      console.log('Restoring user from storage:', userData);
      setUser(userData);
      setIsAuthenticated(true);
    }
  }, []);

  return (
    <AuthContext.Provider value={{ 
      user, 
      isAuthenticated, 
      login, 
      logout,
      isAdmin: isAdmin() 
    }}>
      {children}
    </AuthContext.Provider>
  );
};