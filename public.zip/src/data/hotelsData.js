// src/data/hotelsData.js

export const hotelsByLocation = {
  "Paris": [
    { id: 1, name: "Luxury Paris Hotel", rating: 4.3, price: 200, amenities: ["WiFi", "Pool", "Spa"] },
    { id: 2, name: "Eiffel Tower View", rating: 5, price: 350, amenities: ["WiFi", "Breakfast", "Gym"] },
    { id: 3, name: "Champs Elysees Suite", rating: 4.6, price: 280, amenities: ["WiFi", "Spa", "Bar"] },
    { id: 4, name: "Seine River Hotel", rating: 5, price: 320, amenities: ["WiFi", "Pool", "Restaurant"] }
  ],
  "Tokyo": [
    { id: 5, name: "Tokyo Skyline Hotel", rating: 4.3, price: 300, amenities: ["WiFi", "Gym", "Spa"] },
    { id: 6, name: "Sakura Garden Inn", rating: 5, price: 400, amenities: ["WiFi", "Pool", "Restaurant"] },
    { id: 7, name: "Shinjuku Business Hotel", rating: 4.6, price: 350, amenities: ["WiFi", "Conference", "Gym"] },
    { id: 8, name: "Traditional Ryokan", rating: 5, price: 450, amenities: ["WiFi", "Onsen", "Garden"] }
  ],
  "New York": [
    { id: 9, name: "Manhattan Luxury Suites", rating: 4.3, price: 250, amenities: ["WiFi", "Gym", "Bar"] },
    { id: 10, name: "Central Park View", rating: 5, price: 380, amenities: ["WiFi", "Pool", "Spa"] },
    { id: 11, name: "Times Square Hotel", rating: 4.6, price: 320, amenities: ["WiFi", "Restaurant", "Gym"] },
    { id: 12, name: "Brooklyn Boutique Hotel", rating: 5, price: 280, amenities: ["WiFi", "Bar", "Terrace"] }
  ],
  "Dubai": [
    { id: 13, name: "Burj Khalifa View", rating: 4.3, price: 350, amenities: ["WiFi", "Pool", "Spa"] },
    { id: 14, name: "Palm Jumeirah Resort", rating: 5, price: 500, amenities: ["WiFi", "Private Beach", "Golf"] },
    { id: 15, name: "Desert Oasis Hotel", rating: 4.6, price: 420, amenities: ["WiFi", "Pool", "Spa"] },
    { id: 16, name: "Marina Bay Hotel", rating: 5, price: 380, amenities: ["WiFi", "Yacht Club", "Gym"] }
  ],
  "Bali": [
    { id: 17, name: "Beachfront Villa", rating: 4.3, price: 150, amenities: ["WiFi", "Private Pool", "Beach Access"] },
    { id: 18, name: "Ubud Jungle Retreat", rating: 5, price: 200, amenities: ["WiFi", "Yoga", "Spa"] },
    { id: 19, name: "Seminyak Luxury Resort", rating: 4.6, price: 180, amenities: ["WiFi", "Pool", "Restaurant"] },
    { id: 20, name: "Rice Terrace Hotel", rating: 5, price: 220, amenities: ["WiFi", "Spa", "Cycling"] }
  ],
  "London": [
    { id: 21, name: "Big View Hotel", rating: 4.3, price: 180, amenities: ["WiFi", "Bar", "Conference"] },
    { id: 22, name: "Thames River Suites", rating: 5, price: 280, amenities: ["WiFi", "Spa", "Restaurant"] },
    { id: 23, name: "Royal Garden Hotel", rating: 4.6, price: 240, amenities: ["WiFi", "Garden", "Afternoon Tea"] },
    { id: 24, name: "West End Theater Hotel", rating: 5, price: 260, amenities: ["WiFi", "Bar", "Theater Tickets"] }
  ]
};