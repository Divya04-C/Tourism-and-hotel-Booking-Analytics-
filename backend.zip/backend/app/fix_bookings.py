# backend/app/fix_bookings.py
from pymongo import MongoClient
from config import Settings

def fix_existing_bookings():
    """
    Fix all bookings where user_name is "Unknown User" but user_id has actual username
    """
    try:
        # Use your existing database configuration
        settings = Settings()
        
        # MongoDB connection - using your existing config
        client = MongoClient(settings.mongodb_url)
        db = client[settings.database_name]
        bookings_collection = db.bookings
        
        print("🔧 Starting to fix existing bookings...")
        
        # Find all bookings where user_name is "Unknown User" but user_id has actual username
        query = {
            "user_name": "Unknown User",
            "user_id": {"$ne": None, "$ne": "Unknown User"}
        }
        
        # Get the count of bookings that will be updated
        count = bookings_collection.count_documents(query)
        print(f"📊 Found {count} bookings to fix")
        
        if count == 0:
            print("✅ No bookings need fixing!")
            return
        
        # Update each booking
        updated_count = 0
        bookings_to_fix = bookings_collection.find(query)
        
        for booking in bookings_to_fix:
            try:
                # Set user_name to the value of user_id
                result = bookings_collection.update_one(
                    {"_id": booking["_id"]},
                    {"$set": {"user_name": booking["user_id"]}}
                )
                
                if result.modified_count > 0:
                    updated_count += 1
                    print(f"✅ Fixed booking: {booking.get('booking_id', 'Unknown ID')} - {booking['user_id']}")
                
            except Exception as e:
                print(f"❌ Error fixing booking {booking.get('booking_id', 'Unknown ID')}: {e}")
        
        print(f"\n🎉 Successfully fixed {updated_count} out of {count} bookings!")
        
        # Verify the fix
        remaining_bad = bookings_collection.count_documents({"user_name": "Unknown User"})
        print(f"📋 Remaining 'Unknown User' entries: {remaining_bad}")
        
        return updated_count
        
    except Exception as e:
        print(f"❌ Database connection error: {e}")
        return 0

def fix_all_user_names():
    """
    More comprehensive fix: Update all bookings where user_name doesn't match user_id
    """
    try:
        settings = Settings()
        client = MongoClient(settings.mongodb_url)
        db = client[settings.database_name]
        bookings_collection = db.bookings
        
        print("🔄 Running comprehensive fix for all user_name fields...")
        
        # Find all bookings where user_id exists
        all_bookings = bookings_collection.find({
            "user_id": {"$exists": True, "$ne": None}
        })
        
        updated_count = 0
        for booking in all_bookings:
            user_id = booking.get("user_id")
            user_name = booking.get("user_name")
            
            # If user_name is "Unknown User" or doesn't match user_id, update it
            if user_id and (user_name == "Unknown User" or user_name != user_id):
                result = bookings_collection.update_one(
                    {"_id": booking["_id"]},
                    {"$set": {"user_name": user_id}}
                )
                
                if result.modified_count > 0:
                    updated_count += 1
                    print(f"✅ Updated: {booking.get('booking_id', 'N/A')} - {user_id}")
        
        print(f"\n🎉 Updated {updated_count} bookings in comprehensive fix!")
        return updated_count
        
    except Exception as e:
        print(f"❌ Error in comprehensive fix: {e}")
        return 0

if __name__ == "__main__":
    print("🚀 Tourism Analytics - Booking Data Fixer")
    print("=" * 50)
    
    # Run the basic fix
    fixed_count = fix_existing_bookings()
    
    if fixed_count == 0:
        print("\n🔄 No basic fixes needed, running comprehensive fix...")
        fix_all_user_names()
    
    print("\n" + "=" * 50)
    print("✨ Fix completed!")