from fastapi import APIRouter, HTTPException
from .models import User, BookingCreate, BookingResponse
from .crud import (
    create_booking, 
    get_all_bookings, 
    get_most_visited_locations,
    get_average_price_by_season, 
    get_booking_patterns, 
    get_default_locations,
    get_revenue_analytics,      # Add the new imports
    get_popular_seasons,        # Add the new imports
    mongodb                     # Import mongodb for direct access
)

router = APIRouter()

# Simple user storage (in production use proper authentication)
users_db = {}

@router.post("/register")
async def register(user: User):
    if user.username in users_db:
        raise HTTPException(status_code=400, detail="Username already exists")
    users_db[user.username] = user.dict()
    return {"message": "User registered successfully"}

@router.post("/login")
async def login(user: User):
    if user.username not in users_db or users_db[user.username]["password"] != user.password:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return {"message": "Login successful", "username": user.username}

@router.post("/bookings", response_model=BookingResponse)
async def create_new_booking(booking: BookingCreate):
    try:
        print("🎯 Creating new booking with data:", booking.dict())
        booking_data = booking.dict()
        result = await create_booking(booking_data)
        print("✅ Booking created successfully:", result)
        return result
    except Exception as e:
        print("❌ Error creating booking:", e)
        raise HTTPException(status_code=500, detail=f"Failed to create booking: {str(e)}")

@router.get("/bookings")
async def get_bookings():
    return await get_all_bookings()

@router.get("/analytics/most-visited")
async def analytics_most_visited():
    return await get_most_visited_locations()

@router.get("/analytics/average-price-season")
async def analytics_average_price():
    return await get_average_price_by_season()

@router.get("/analytics/booking-patterns")
async def analytics_booking_patterns():
    return await get_booking_patterns()

@router.get("/locations")
async def get_locations():
    return await get_default_locations()

# NEW ROUTES

@router.get("/analytics/revenue")
async def analytics_revenue():
    """Get overall revenue analytics"""
    return await get_revenue_analytics()

@router.get("/analytics/popular-seasons")
async def analytics_popular_seasons():
    """Get popular seasons analytics"""
    return await get_popular_seasons()

@router.get("/bookings/user/{user_id}")
async def get_user_bookings(user_id: str):
    """Get all bookings for a specific user"""
    try:
        # Use the imported mongodb instance directly
        bookings = await mongodb.database.bookings.find(
            {"user_id": user_id}
        ).sort("booking_date", -1).to_list(1000)
        
        for booking in bookings:
            booking["id"] = booking["_id"]
        return bookings
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/fix-bookings", tags=["admin"])
async def fix_bookings():
    """
    Admin endpoint to fix booking data where user_name is "Unknown User"
    """
    try:
        print("🔧 Starting to fix bookings...")
        
        # Use the async mongodb instance from crud
        # Find all bookings where user_name is "Unknown User" but user_id has actual username
        query = {
            "user_name": "Unknown User",
            "user_id": {"$ne": None, "$ne": "Unknown User"}
        }
        
        # Get the count of bookings that will be updated
        count = await mongodb.database.bookings.count_documents(query)
        print(f"📊 Found {count} bookings to fix")
        
        if count == 0:
            return {
                "message": "No bookings need fixing!",
                "modified_count": 0,
                "status": "success"
            }
        
        # Update each booking by setting user_name to user_id
        # Note: For field reference updates, we need to use aggregation pipeline format
        result = await mongodb.database.bookings.update_many(
            query,
            [{"$set": {"user_name": "$user_id"}}]  # Use aggregation pipeline format for field references
        )
        
        print(f"✅ Fixed {result.modified_count} bookings")
        
        return {
            "message": f"Successfully fixed {result.modified_count} bookings",
            "modified_count": result.modified_count,
            "status": "success"
        }
        
    except Exception as e:
        print(f"❌ Error fixing bookings: {e}")
        raise HTTPException(status_code=500, detail=f"Error fixing bookings: {str(e)}")