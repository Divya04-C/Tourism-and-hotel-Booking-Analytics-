from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class User(BaseModel):
    username: str
    password: str

class Hotel(BaseModel):
    id: int
    name: str
    rating: float
    price: float
    amenities: List[str]

class BookingCreate(BaseModel):
    booking_id: str  # Frontend-generated booking ID
    user_id: str
    user_name: str
    locations: List[str]
    hotels: Dict[str, Hotel]
    booking_date: str
    total_price: float

class BookingResponse(BaseModel):
    id: str
    booking_id: str  # CRITICAL: Add this line
    user_id: str
    user_name: str
    locations: List[str]
    hotels: Dict[str, Hotel]
    booking_date: str
    season: str
    total_price: float
    booking_pattern: str

class Location(BaseModel):
    name: str
    fee: float

# Default locations with updated fees
DEFAULT_LOCATIONS = [
    {"name": "Paris", "fee": 1200},
    {"name": "New York", "fee": 1500},
    {"name": "Tokyo", "fee": 1800},
    {"name": "London", "fee": 1300},
    {"name": "Dubai", "fee": 1600},
    {"name": "Bali", "fee": 1100}
]