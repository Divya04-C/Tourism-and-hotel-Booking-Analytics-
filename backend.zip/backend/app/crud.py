from motor.motor_asyncio import AsyncIOMotorClient
from bson import ObjectId
from datetime import datetime
from typing import Optional
from .models import DEFAULT_LOCATIONS
from .utils import get_season_from_date, get_booking_pattern
from .config import settings 
 # ✅ Import settings from config

class MongoDB:
    client: Optional[AsyncIOMotorClient] = None # type: ignore
    database = None

mongodb = MongoDB()

async def connect_to_mongo():
    """Connect to MongoDB using settings from config"""
    try:
        print(f"🔗 Connecting to MongoDB: {settings.MONGODB_URL}")
        mongodb.client = AsyncIOMotorClient(settings.MONGODB_URL)
        mongodb.database = mongodb.client[settings.DATABASE_NAME]
        
        # Test the connection
        await mongodb.client.admin.command('ping')
        print("✅ Successfully connected to MongoDB")
        
        # Create indexes for better performance
        await mongodb.database.bookings.create_index("booking_id")
        await mongodb.database.bookings.create_index("user_id")
        await mongodb.database.bookings.create_index("booking_date")
        print("✅ Database indexes created")
        
    except Exception as e:
        print(f"❌ Failed to connect to MongoDB: {e}")
        raise e

async def close_mongo_connection():
    """Close MongoDB connection"""
    if mongodb.client:
        mongodb.client.close()
        print("🔌 Disconnected from MongoDB")

async def create_booking(booking_data: dict):
    """Create a new booking using the frontend-generated booking_id"""
    try:
        print("🎯 Received booking data for creation:", booking_data)
        
        # ✅ Use the booking_id from frontend as _id
        if "booking_id" in booking_data and booking_data["booking_id"]:
            booking_data["_id"] = booking_data["booking_id"]
            print(f"✅ Using frontend booking ID: {booking_data['booking_id']}")
        else:
            # Fallback: generate a new ID
            booking_data["_id"] = f"BK-{str(ObjectId())}"
            print("⚠️ No booking_id from frontend, generated new ID")
        
        # ✅ Ensure user_name is properly set
        if not booking_data.get("user_name") and booking_data.get("user_id"):
            booking_data["user_name"] = booking_data["user_id"]
            print(f"✅ Set user_name from user_id: {booking_data['user_name']}")
        
        # ✅ Add creation timestamp
        booking_data["created_at"] = datetime.utcnow()
        
        # ✅ Calculate season and booking pattern
        try:
            date_str = booking_data["booking_date"]
            print("📅 Parsing date:", date_str)
            booking_data["season"] = get_season_from_date(date_str)
            booking_data["booking_pattern"] = get_booking_pattern(date_str)
            print(f"🌤️ Calculated - Season: {booking_data['season']}, Pattern: {booking_data['booking_pattern']}")
        except Exception as e:
            print("❌ Season detection error:", e)
            booking_data["season"] = "Unknown"
            booking_data["booking_pattern"] = "Unknown"
        
        print("💾 Final booking data to insert:", booking_data)
        
        # ✅ Insert into MongoDB
        result = await mongodb.database.bookings.insert_one(booking_data)
        print(f"✅ MongoDB insert successful - ID: {result.inserted_id}")
        
        # ✅ Return the complete booking data WITH booking_id
        created_booking = await get_booking_by_id(str(result.inserted_id))
        if created_booking:
            # Ensure booking_id field is present for frontend
            created_booking["booking_id"] = created_booking["_id"]
            print(f"🎉 Booking created successfully: {created_booking['booking_id']}")
        return created_booking
        
    except Exception as e:
        print("❌ Error in create_booking:", e)
        raise e

async def get_booking_by_id(booking_id: str):
    """Get booking by ID with proper field mapping"""
    try:
        print(f"🔍 Fetching booking by ID: {booking_id}")
        booking = await mongodb.database.bookings.find_one({"_id": booking_id})
        
        if booking:
            # ✅ Ensure all required fields are present
            booking["id"] = booking["_id"]
            booking["booking_id"] = booking["_id"]  # Add booking_id field for frontend
            
            # Ensure user_name is set
            if not booking.get("user_name") and booking.get("user_id"):
                booking["user_name"] = booking["user_id"]
            
            print(f"✅ Found booking: {booking['booking_id']} for {booking['user_name']}")
            return booking
        
        print(f"❌ No booking found with ID: {booking_id}")
        return None
        
    except Exception as e:
        print(f"❌ Error getting booking by ID {booking_id}: {e}")
        return None

async def get_all_bookings():
    """Get all bookings from the database with proper field mapping"""
    try:
        print("📊 Fetching all bookings from database...")
        bookings = await mongodb.database.bookings.find().sort("_id", -1).to_list(1000)
        
        # ✅ Process each booking to ensure consistent field names
        processed_bookings = []
        for booking in bookings:
            processed_booking = {
                "id": booking["_id"],
                "booking_id": booking["_id"],  # Ensure booking_id field exists
                "user_id": booking.get("user_id", "Unknown"),
                "user_name": booking.get("user_name", booking.get("user_id", "Unknown User")),
                "locations": booking.get("locations", []),
                "hotels": booking.get("hotels", {}),
                "booking_date": booking.get("booking_date", "Unknown"),
                "total_price": booking.get("total_price", 0),
                "season": booking.get("season", "Unknown"),
                "booking_pattern": booking.get("booking_pattern", "Unknown"),
                "created_at": booking.get("created_at")
            }
            processed_bookings.append(processed_booking)
        
        print(f"✅ Retrieved {len(processed_bookings)} bookings from database")
        return processed_bookings
        
    except Exception as e:
        print(f"❌ Error getting all bookings: {e}")
        return []

async def get_most_visited_locations():
    """MapReduce-like aggregation for most visited locations"""
    try:
        print("📍 Calculating most visited locations...")
        pipeline = [
            {"$unwind": "$locations"},
            {"$group": {"_id": "$locations", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
            {"$limit": 10}
        ]
        result = await mongodb.database.bookings.aggregate(pipeline).to_list(1000)
        print(f"📍 Most visited locations: {len(result)} results")
        return result
    except Exception as e:
        print(f"❌ Error in get_most_visited_locations: {e}")
        return []

async def get_average_price_by_season():
    """Average price by season"""
    try:
        print("🌤️ Calculating average price by season...")
        pipeline = [
            {"$group": {"_id": "$season", "average_price": {"$avg": "$total_price"}}},
            {"$sort": {"_id": 1}}
        ]
        result = await mongodb.database.bookings.aggregate(pipeline).to_list(1000)
        print(f"🌤️ Average price by season: {len(result)} results")
        return result
    except Exception as e:
        print(f"❌ Error in get_average_price_by_season: {e}")
        return []

async def get_booking_patterns():
    """User booking patterns (weekday vs weekend)"""
    try:
        print("📅 Calculating booking patterns...")
        pipeline = [
            {"$group": {"_id": "$booking_pattern", "count": {"$sum": 1}}},
            {"$sort": {"_id": 1}}
        ]
        result = await mongodb.database.bookings.aggregate(pipeline).to_list(1000)
        print(f"📅 Booking patterns: {len(result)} results")
        return result
    except Exception as e:
        print(f"❌ Error in get_booking_patterns: {e}")
        return []

async def get_popular_seasons():
    """Get booking distribution by season"""
    try:
        print("🌞 Calculating popular seasons...")
        pipeline = [
            {"$group": {"_id": "$season", "bookings": {"$sum": 1}}},
            {"$sort": {"bookings": -1}}
        ]
        result = await mongodb.database.bookings.aggregate(pipeline).to_list(1000)
        print(f"🌞 Popular seasons: {len(result)} results")
        return result
    except Exception as e:
        print(f"❌ Error in get_popular_seasons: {e}")
        return []

async def get_revenue_analytics():
    """Get total revenue and booking counts"""
    try:
        print("💰 Calculating revenue analytics...")
        pipeline = [
            {
                "$group": {
                    "_id": None,
                    "total_revenue": {"$sum": "$total_price"},
                    "total_bookings": {"$sum": 1},
                    "average_booking_value": {"$avg": "$total_price"}
                }
            }
        ]
        result = await mongodb.database.bookings.aggregate(pipeline).to_list(1000)
        
        # If no bookings, return default values
        if not result:
            default_result = {
                "total_revenue": 0,
                "total_bookings": 0,
                "average_booking_value": 0
            }
            print("💰 No bookings for revenue analytics, returning defaults")
            return [default_result]
        
        print(f"💰 Revenue analytics calculated: {result[0]}")
        return result
        
    except Exception as e:
        print(f"❌ Error in get_revenue_analytics: {e}")
        return [{
            "total_revenue": 0,
            "total_bookings": 0,
            "average_booking_value": 0
        }]

async def get_default_locations():
    """Get default locations"""
    return DEFAULT_LOCATIONS

async def get_database_stats():
    """Get database statistics for debugging"""
    try:
        stats = await mongodb.database.command("dbStats")
        booking_count = await mongodb.database.bookings.count_documents({})
        return {
            "database": stats["db"],
            "collections": stats["collections"],
            "objects": stats["objects"],
            "total_bookings": booking_count,
            "data_size": stats["dataSize"]
        }
    except Exception as e:
        print(f"❌ Error getting database stats: {e}")
        return {"error": str(e)}