from datetime import datetime

def get_season_from_date(date_str: str) -> str:
    """Determine season from booking date"""
    try:
        date_obj = datetime.strptime(date_str, "%Y-%m-%d")
        month = date_obj.month
        
        if month in [3, 4, 5]:
            return "Spring"
        elif month in [6, 7, 8]:
            return "Summer"
        elif month in [9, 10, 11]:
            return "Fall"
        else:
            return "Winter"
    except Exception as e:
        print(f"Error in get_season_from_date: {e}")
        return "Unknown"

def get_booking_pattern(date_str: str) -> str:
    """Determine if booking is on weekday or weekend"""
    try:
        date_obj = datetime.strptime(date_str, "%Y-%m-%d")
        weekday = date_obj.weekday()
        return "Weekend" if weekday >= 5 else "Weekday"
    except Exception as e:
        print(f"Error in get_booking_pattern: {e}")
        return "Unknown"